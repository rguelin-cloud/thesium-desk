"""
data_macro.py — US Systemic Vulnerability Indicator
Adapted from dashboard_us_auto_v2.py by R. Guelin
Fetches FRED data, computes 4 sub-scores → GlobalScore 0-100, correlation signals.
"""

import requests
import numpy as np
import pandas as pd
from datetime import datetime
import traceback
import math


def _safe_float(val, default=None):
    """Convert to JSON-safe float — replaces inf/nan with default."""
    if val is None:
        return default
    try:
        f = float(val)
        if math.isinf(f) or math.isnan(f):
            return default
        return f
    except (TypeError, ValueError):
        return default

# ============================================================
# FRED API KEY & SERIES
# ============================================================

FRED_API_KEY = "8d8ef4b05a6d63cec4d7abb7a6031d84"

FRED_SERIES = {
    "debt_gdp":       "GFDEGDQ188S",
    "deficit_gdp":    "MTSDS133FMS",
    "cpi_yoy":        "CPIAUCSL",
    "core_cpi_yoy":   "CPILFESL",
    "hy_spread":      "BAMLH0A0HYM2",
    "ccc_oas":        "BAMLH0A3HYC",
    "dxy":            "DTWEXBGS",
    "u3":             "UNRATE",
    "u6":             "U6RATE",
    "participation":  "CIVPART",
    "unemp_duration": "UEMPMEAN",
    "productivity":   "OPHNFB",
    "employment":     "PAYEMS",
    "gdp_yoy":        "A191RL1Q225SBEA",
}

BOUNDS = {
    "debt_gdp":       (50,   130),
    "deficit_gdp":    (0,    15),
    "int_rev":        (2,    25),
    "cpi_yoy":        (0,    8),
    "core_cpi_yoy":   (0,    6),
    "hy_spread":      (100,  1000),
    "ccc_oas":        (400,  1500),
    "dxy":            (90,   130),
    "u3":             (3,    10),
    "u6":             (6,    17),
    "participation":  (60,   68),
    "unemp_duration": (10,   35),
    "productivity":   (1,    3),
    "gdp_emp_gap":    (0,    5),
    "ai_tension":     (0,    100),
}

# ============================================================
# BTC & NDX MONTHLY DATA (2015 → 2026-02)
# ============================================================

BTC_MONTHLY = {
    '2015-01': 217,  '2015-02': 254,  '2015-03': 244,  '2015-04': 236,
    '2015-05': 230,  '2015-06': 263,  '2015-07': 285,  '2015-08': 230,
    '2015-09': 236,  '2015-10': 314,  '2015-11': 377,  '2015-12': 431,
    '2016-01': 369,  '2016-02': 438,  '2016-03': 417,  '2016-04': 448,
    '2016-05': 531,  '2016-06': 673,  '2016-07': 625,  '2016-08': 575,
    '2016-09': 610,  '2016-10': 701,  '2016-11': 746,  '2016-12': 964,
    '2017-01': 970,  '2017-02': 1190, '2017-03': 1070, '2017-04': 1347,
    '2017-05': 2287, '2017-06': 2544, '2017-07': 2875, '2017-08': 4700,
    '2017-09': 4340, '2017-10': 6139, '2017-11': 9820, '2017-12': 14156,
    '2018-01': 10230,'2018-02': 10500,'2018-03': 6930, '2018-04': 9240,
    '2018-05': 7330, '2018-06': 6400, '2018-07': 8200, '2018-08': 7000,
    '2018-09': 6630, '2018-10': 6370, '2018-11': 4017, '2018-12': 3693,
    '2019-01': 3457, '2019-02': 3811, '2019-03': 4099, '2019-04': 5300,
    '2019-05': 8720, '2019-06': 10820,'2019-07': 10090,'2019-08': 9630,
    '2019-09': 8300, '2019-10': 9250, '2019-11': 7570, '2019-12': 7240,
    '2020-01': 9350, '2020-02': 8776, '2020-03': 6430, '2020-04': 8630,
    '2020-05': 9455, '2020-06': 9143, '2020-07': 11350,'2020-08': 11655,
    '2020-09': 10800,'2020-10': 13800,'2020-11': 19700,'2020-12': 29300,
    '2021-01': 33100,'2021-02': 45200,'2021-03': 58900,'2021-04': 57800,
    '2021-05': 37300,'2021-06': 35000,'2021-07': 41500,'2021-08': 47100,
    '2021-09': 43800,'2021-10': 60600,'2021-11': 56900,'2021-12': 46200,
    '2022-01': 38500,'2022-02': 43200,'2022-03': 45500,'2022-04': 37700,
    '2022-05': 31800,'2022-06': 19000,'2022-07': 23300,'2022-08': 20050,
    '2022-09': 19420,'2022-10': 20490,'2022-11': 16550,'2022-12': 16530,
    '2023-01': 23100,'2023-02': 23400,'2023-03': 28500,'2023-04': 29300,
    '2023-05': 27700,'2023-06': 30500,'2023-07': 29200,'2023-08': 26000,
    '2023-09': 26900,'2023-10': 34400,'2023-11': 37700,'2023-12': 42265,
    '2024-01': 42500,'2024-02': 62400,'2024-03': 71200,'2024-04': 59600,
    '2024-05': 68500,'2024-06': 63000,'2024-07': 66400,'2024-08': 59000,
    '2024-09': 63300,'2024-10': 72300,'2024-11': 96500,'2024-12': 93400,
    '2025-01': 105000,'2025-02': 84000,'2025-03': 82000,'2025-04': 93000,
    '2025-05': 107000,'2025-06': 107000,'2025-07': 118000,'2025-08': 108000,
    '2025-09': 114000,'2025-10': 109000,'2025-11': 90000,'2025-12': 87500,
    '2026-01': 78600,'2026-02': 65000,
}

NDX_MONTHLY = {
    '2015-01': 4105, '2015-02': 4386, '2015-03': 4356, '2015-04': 4461,
    '2015-05': 4534, '2015-06': 4358, '2015-07': 4548, '2015-08': 4097,
    '2015-09': 4090, '2015-10': 4498, '2015-11': 4639, '2015-12': 4574,
    '2016-01': 4189, '2016-02': 4127, '2016-03': 4470, '2016-04': 4394,
    '2016-05': 4531, '2016-06': 4366, '2016-07': 4700, '2016-08': 4781,
    '2016-09': 4873, '2016-10': 4761, '2016-11': 4862, '2016-12': 4863,
    '2017-01': 5151, '2017-02': 5352, '2017-03': 5370, '2017-04': 5497,
    '2017-05': 5781, '2017-06': 5775, '2017-07': 5945, '2017-08': 6026,
    '2017-09': 6074, '2017-10': 6291, '2017-11': 6459, '2017-12': 6651,
    '2018-01': 6898, '2018-02': 6777, '2018-03': 6543, '2018-04': 6640,
    '2018-05': 7013, '2018-06': 7147, '2018-07': 7530, '2018-08': 7571,
    '2018-09': 7551, '2018-10': 6837, '2018-11': 6834, '2018-12': 6192,
    '2019-01': 6738, '2019-02': 7092, '2019-03': 7419, '2019-04': 7750,
    '2019-05': 7190, '2019-06': 7730, '2019-07': 7968, '2019-08': 7748,
    '2019-09': 7822, '2019-10': 8161, '2019-11': 8399, '2019-12': 8733,
    '2020-01': 9052, '2020-02': 8691, '2020-03': 7327, '2020-04': 8890,
    '2020-05': 9368, '2020-06': 10059,'2020-07': 10745,'2020-08': 12056,
    '2020-09': 11167,'2020-10': 11201,'2020-11': 12205,'2020-12': 12888,
    '2021-01': 13072,'2021-02': 13434,'2021-03': 13246,'2021-04': 13900,
    '2021-05': 13539,'2021-06': 14510,'2021-07': 15108,'2021-08': 15672,
    '2021-09': 14933,'2021-10': 15978,'2021-11': 16166,'2021-12': 16320,
    '2022-01': 14955,'2022-02': 14753,'2022-03': 14919,'2022-04': 13411,
    '2022-05': 12857,'2022-06': 11503,'2022-07': 13024,'2022-08': 13074,
    '2022-09': 11127,'2022-10': 11403,'2022-11': 11813,'2022-12': 10939,
    '2023-01': 12038,'2023-02': 12254,'2023-03': 13290,'2023-04': 13272,
    '2023-05': 14177,'2023-06': 15163,'2023-07': 15560,'2023-08': 15071,
    '2023-09': 14712,'2023-10': 14579,'2023-11': 16074,'2023-12': 16825,
    '2024-01': 17599,'2024-02': 17997,'2024-03': 18285,'2024-04': 17443,
    '2024-05': 18941,'2024-06': 19751,'2024-07': 19362,'2024-08': 19490,
    '2024-09': 19791,'2024-10': 20001,'2024-11': 21117,'2024-12': 21314,
    '2025-01': 21500,'2025-02': 20500,'2025-03': 18900,'2025-04': 17700,
    '2025-05': 19700,'2025-06': 20500,'2025-07': 22000,'2025-08': 22500,
    '2025-09': 23000,'2025-10': 26100,'2025-11': 25500,'2025-12': 25250,
    '2026-01': 21000,'2026-02': 25000,
}

# ============================================================
# UTILITY FUNCTIONS
# ============================================================

def _scale(value, vmin, vmax, invert=False):
    v = max(min(float(value), vmax), vmin)
    score = 100.0 * (v - vmin) / (vmax - vmin)
    return 100.0 - score if invert else score


def _regime_label(s):
    if s < 20:   return "FAIBLE"
    elif s < 40: return "MODEREE"
    elif s < 60: return "ELEVEE"
    elif s < 80: return "PRE-CRISE"
    else:        return "STRESS SYSTEMIQUE"


def _regime_color(s):
    """Return a CSS color for the score level."""
    if s < 20:   return "#70AD47"   # green
    elif s < 40: return "#9DC3E6"   # blue
    elif s < 60: return "#FFD966"   # yellow
    elif s < 80: return "#F4B942"   # orange
    else:        return "#C00000"   # red


def _fetch_fred(series_id, api_key, start_date="2010-01-01"):
    """Fetch a single FRED series. Returns a pandas Series or None."""
    url = (
        f"https://api.stlouisfed.org/fred/series/observations"
        f"?series_id={series_id}&api_key={api_key}"
        f"&observation_start={start_date}&file_type=json"
    )
    try:
        r = requests.get(url, timeout=15)
        if r.status_code == 200:
            obs = r.json().get("observations", [])
            df = pd.DataFrame(obs)[["date", "value"]]
            df["date"] = pd.to_datetime(df["date"])
            df["value"] = pd.to_numeric(df["value"], errors="coerce")
            df = df.dropna().set_index("date").sort_index()
            return df["value"]
    except Exception:
        pass
    return None


def _compute_yoy_pct(series):
    """Convert a raw index series (e.g. CPI level) to YoY percentage change."""
    if series is None or len(series) < 13:
        return None
    yoy = series.pct_change(periods=12) * 100
    yoy = yoy.dropna()
    return yoy if len(yoy) > 0 else None


def _compute_deficit_gdp_ratio(deficit_series, api_key):
    """
    Compute Deficit/GDP ratio.
    MTSDS133FMS is monthly budget surplus/deficit in millions USD.
    We sum trailing 12 months and divide by latest annual GDP.
    """
    if deficit_series is None or len(deficit_series) < 12:
        return None
    # Rolling 12-month sum of deficit (in millions)
    rolling_deficit = deficit_series.rolling(12).sum()
    # Fetch nominal GDP (quarterly, billions) — FRED series GDP
    gdp_series = _fetch_fred("GDP", api_key, start_date="2010-01-01")
    if gdp_series is None or len(gdp_series) == 0:
        return None
    # GDP is in billions, deficit in millions → convert deficit to billions
    ratio = (rolling_deficit / 1000) / gdp_series.reindex(rolling_deficit.index, method="ffill") * 100
    ratio = ratio.dropna()
    # The deficit series is negative for deficits, so negate for display as positive % deficit
    return -ratio if len(ratio) > 0 else None


def _get_fallback_data():
    """Fallback data Q4 2025 if FRED API is unavailable."""
    months = pd.date_range(end="2025-12-31", periods=12, freq="ME")
    return {
        "debt_gdp":       pd.Series([121,121,121,121,121.5,121.5,122,122,122,122.5,122.5,123], index=months),
        "deficit_gdp":    pd.Series([6.5]*4 + [6.7]*4 + [6.9]*4, index=months),
        "cpi_yoy":        pd.Series([3.5,3.4,3.3,3.2,3.0,2.9,2.9,2.8,2.7,2.7,2.7,2.9], index=months),
        "core_cpi_yoy":   pd.Series([3.8,3.7,3.6,3.4,3.3,3.2,3.2,3.1,3.0,2.8,2.7,2.7], index=months),
        "hy_spread":      pd.Series([320,315,310,300,295,290,285,310,320,330,340,350], index=months),
        "dxy":            pd.Series([103,104,104,104.5,105,104,103,104,104.5,105,104,105], index=months),
        "u3":             pd.Series([3.9,3.9,4.0,4.0,4.1,4.1,4.2,4.3,4.4,4.4,4.4,4.3], index=months),
        "u6":             pd.Series([7.3,7.3,7.4,7.4,7.5,7.6,7.7,7.8,7.8,7.8,7.8,7.6], index=months),
        "participation":  pd.Series([62.5]*12, index=months),
        "unemp_duration": pd.Series([19,19,18.5,18.5,18,18,18,18,18.5,18.5,18,18], index=months),
        "productivity":   pd.Series([1.8,1.9,1.9,2.0,2.1,2.1,2.0,2.0,2.0,2.0,2.0,2.0], index=months),
        "ai_tension":     pd.Series([50]*12, index=months),
        "gdp_yoy":        pd.Series([2.5]*12, index=months),
        "employment":     pd.Series([2.0]*12, index=months),
    }


# ============================================================
# SCORE COMPUTATION
# ============================================================

def _compute_scores(raw):
    """Compute 12-month history of sub-scores and GlobalScore."""
    months = raw["cpi_yoy"].index[-12:]
    records = []

    for dt in months:
        def v(key, default=0.0):
            s = raw.get(key)
            if s is None:
                return default
            try:
                idx = s.index.get_indexer([dt], method="ffill")[0]
                return float(s.iloc[idx]) if idx >= 0 else default
            except Exception:
                return default

        debt_gdp       = v("debt_gdp",      123)
        deficit_gdp    = v("deficit_gdp",    7.0)
        cpi_yoy        = v("cpi_yoy",        2.9)
        core_cpi_yoy   = v("core_cpi_yoy",   2.7)
        hy_spread      = v("hy_spread",      350)
        ccc_oas        = v("ccc_oas",        900)
        dxy            = v("dxy",            105)
        u3             = v("u3",             4.4)
        u6             = v("u6",             7.8)
        participation  = v("participation",  62.5)
        unemp_dur      = v("unemp_duration", 18)
        productivity   = v("productivity",   2.0)
        ai_tension     = v("ai_tension",     50)
        gdp_yoy        = v("gdp_yoy",        2.5)
        emp_yoy        = v("employment",     2.0)
        int_rev        = 6.5

        # DebtScore (35%)
        ds1 = _scale(debt_gdp,    *BOUNDS["debt_gdp"])
        ds2 = _scale(deficit_gdp, *BOUNDS["deficit_gdp"])
        ds3 = _scale(int_rev,     *BOUNDS["int_rev"])
        DebtScore = round(np.mean([ds1, ds2, ds3]), 1)

        # PriceFXScore (25%)
        ps1 = _scale(cpi_yoy,      *BOUNDS["cpi_yoy"])
        ps2 = _scale(core_cpi_yoy, *BOUNDS["core_cpi_yoy"])
        ps3 = _scale(hy_spread,    *BOUNDS["hy_spread"])
        ps4 = _scale(dxy,          *BOUNDS["dxy"])
        PriceFXScore = round(np.mean([ps1, ps2, ps3, ps4]), 1)

        # JobsScore (20%)
        js1 = _scale(u3,            *BOUNDS["u3"])
        js2 = _scale(u6,            *BOUNDS["u6"])
        js3 = _scale(participation, *BOUNDS["participation"], invert=True)
        js4 = _scale(unemp_dur,     *BOUNDS["unemp_duration"])
        JobsScore = round(np.mean([js1, js2, js3, js4]), 1)

        # IAScore (20%)
        gap = abs(gdp_yoy - emp_yoy)
        is1 = _scale(productivity, *BOUNDS["productivity"], invert=True)
        is2 = _scale(gap,          *BOUNDS["gdp_emp_gap"])
        is3 = ai_tension
        IAScore = round(np.mean([is1, is2, is3]), 1)

        # GlobalScore
        GlobalScore = round(0.35*DebtScore + 0.25*PriceFXScore + 0.20*JobsScore + 0.20*IAScore, 1)

        records.append({
            "date":           dt.strftime("%Y-%m"),
            "debt_gdp":       round(debt_gdp, 1),
            "deficit_gdp":    round(deficit_gdp, 1),
            "cpi_yoy":        round(cpi_yoy, 1),
            "core_cpi_yoy":   round(core_cpi_yoy, 1),
            "hy_spread":      round(hy_spread, 0),
            "ccc_oas":        round(ccc_oas, 0),
            "dxy":            round(dxy, 1),
            "u3":             round(u3, 1),
            "u6":             round(u6, 1),
            "participation":  round(participation, 1),
            "unemp_duration": round(unemp_dur, 1),
            "productivity":   round(productivity, 1),
            "DebtScore":      DebtScore,
            "PriceFXScore":   PriceFXScore,
            "JobsScore":      JobsScore,
            "IAScore":        IAScore,
            "GlobalScore":    GlobalScore,
        })

    return records


# ============================================================
# CORRELATION SIGNALS
# ============================================================

def _compute_correlation_signals(score_records):
    """Compute rolling 24m correlation GlobalScore vs BTC/NDX + front-run signals."""
    # Build global score map from score_records
    gs_map = {r["date"]: r["GlobalScore"] for r in score_records}
    debt_map = {r["date"]: r["DebtScore"] for r in score_records}
    price_map = {r["date"]: r["PriceFXScore"] for r in score_records}

    all_months = sorted(BTC_MONTHLY.keys())
    hist = pd.DataFrame({
        "Date":  pd.to_datetime([m + "-01" for m in all_months]),
        "BTC":   [BTC_MONTHLY[m] for m in all_months],
        "NDX":   [NDX_MONTHLY.get(m, np.nan) for m in all_months],
    })
    hist["month_key"] = hist["Date"].dt.strftime("%Y-%m")
    hist["GlobalScore"] = hist["month_key"].map(gs_map)
    hist["DebtScore"] = hist["month_key"].map(debt_map)
    hist["PriceFXScore"] = hist["month_key"].map(price_map)

    # Interpolate for months without computed score
    hist["GlobalScore"] = pd.to_numeric(hist["GlobalScore"], errors="coerce")
    hist["GlobalScore"] = hist["GlobalScore"].interpolate(method="linear").ffill().bfill()
    hist = hist.sort_values("Date").reset_index(drop=True)

    # Rolling 24m correlations
    gs_s = hist.set_index("Date")["GlobalScore"]
    btc_s = hist.set_index("Date")["BTC"]
    ndx_s = hist.set_index("Date")["NDX"]

    roll_btc = gs_s.rolling(24).corr(btc_s).reset_index()
    roll_btc.columns = ["Date", "corr_btc_24m"]
    roll_ndx = gs_s.rolling(24).corr(ndx_s).reset_index()
    roll_ndx.columns = ["Date", "corr_ndx_24m"]

    hist = hist.merge(roll_btc, on="Date", how="left")
    hist = hist.merge(roll_ndx, on="Date", how="left")

    # Signal 1: Zero-crossing
    hist["signal_btc_cross"] = ""
    hist["signal_ndx_cross"] = ""
    for i in range(1, len(hist)):
        pb = hist.loc[i-1, "corr_btc_24m"]
        cb = hist.loc[i,   "corr_btc_24m"]
        pn = hist.loc[i-1, "corr_ndx_24m"]
        cn = hist.loc[i,   "corr_ndx_24m"]
        if pd.notna(pb) and pd.notna(cb):
            if pb < 0 and cb >= 0: hist.loc[i, "signal_btc_cross"] = "BUY_SETUP"
            elif pb > 0 and cb <= 0: hist.loc[i, "signal_btc_cross"] = "SELL_SETUP"
        if pd.notna(pn) and pd.notna(cn):
            if pn < 0 and cn >= 0: hist.loc[i, "signal_ndx_cross"] = "BUY_SETUP"
            elif pn > 0 and cn <= 0: hist.loc[i, "signal_ndx_cross"] = "SELL_SETUP"

    # Signal 2: Intensity
    hist["signal_btc_intensity"] = ""
    hist["signal_ndx_intensity"] = ""
    for i in range(len(hist)):
        cb = hist.loc[i, "corr_btc_24m"]
        cn = hist.loc[i, "corr_ndx_24m"]
        if pd.notna(cb):
            if cb < -0.7: hist.loc[i, "signal_btc_intensity"] = "STRONG_INVERSE"
            elif cb > 0.7: hist.loc[i, "signal_btc_intensity"] = "STRONG_POSITIVE"
        if pd.notna(cn):
            if cn < -0.7: hist.loc[i, "signal_ndx_intensity"] = "STRONG_INVERSE"
            elif cn > 0.7: hist.loc[i, "signal_ndx_intensity"] = "STRONG_POSITIVE"

    # Signal 3: Velocity
    hist["corr_btc_velocity"] = hist["corr_btc_24m"].diff(3)
    hist["corr_ndx_velocity"] = hist["corr_ndx_24m"].diff(3)
    hist["signal_btc_velocity"] = ""
    hist["signal_ndx_velocity"] = ""
    for i in range(3, len(hist)):
        vb = hist.loc[i, "corr_btc_velocity"]
        vn = hist.loc[i, "corr_ndx_velocity"]
        if pd.notna(vb):
            if vb > 0.3:  hist.loc[i, "signal_btc_velocity"] = "ROTATION_FAST_PLUS"
            elif vb < -0.3: hist.loc[i, "signal_btc_velocity"] = "ROTATION_FAST_MINUS"
        if pd.notna(vn):
            if vn > 0.3:  hist.loc[i, "signal_ndx_velocity"] = "ROTATION_FAST_PLUS"
            elif vn < -0.3: hist.loc[i, "signal_ndx_velocity"] = "ROTATION_FAST_MINUS"

    # Composite signal
    hist["composite_btc"] = ""
    hist["composite_ndx"] = ""
    for i in range(len(hist)):
        sigs_b = [hist.loc[i, c] for c in ["signal_btc_cross","signal_btc_intensity","signal_btc_velocity"]]
        sigs_n = [hist.loc[i, c] for c in ["signal_ndx_cross","signal_ndx_intensity","signal_ndx_velocity"]]
        active_b = [s for s in sigs_b if s != ""]
        active_n = [s for s in sigs_n if s != ""]
        if len(active_b) >= 2:
            if any("BUY" in s or "POSITIVE" in s or "PLUS" in s for s in active_b):
                hist.loc[i, "composite_btc"] = "BULLISH_SETUP"
            elif any("SELL" in s or "INVERSE" in s or "MINUS" in s for s in active_b):
                hist.loc[i, "composite_btc"] = "BEARISH_SETUP"
        if len(active_n) >= 2:
            if any("BUY" in s or "POSITIVE" in s or "PLUS" in s for s in active_n):
                hist.loc[i, "composite_ndx"] = "BULLISH_SETUP"
            elif any("SELL" in s or "INVERSE" in s or "MINUS" in s for s in active_n):
                hist.loc[i, "composite_ndx"] = "BEARISH_SETUP"

    # Return only last 24 rows for the API (last 2 years) + latest summary
    recent = hist.tail(24).reset_index(drop=True)
    last = hist.iloc[-1]

    correlation_data = []
    for _, row in recent.iterrows():
        correlation_data.append({
            "date":               row["Date"].strftime("%Y-%m"),
            "global_score":       round(_safe_float(row["GlobalScore"], 0), 1),
            "btc_price":           int(row["BTC"]) if pd.notna(row["BTC"]) else None,
            "qqq_price":           int(row["NDX"]) if pd.notna(row["NDX"]) else None,
            "corr_btc_24m":       round(_safe_float(row["corr_btc_24m"], 0), 3) if _safe_float(row["corr_btc_24m"]) is not None else None,
            "corr_ndx_24m":       round(_safe_float(row["corr_ndx_24m"], 0), 3) if _safe_float(row["corr_ndx_24m"]) is not None else None,
            "signal_btc_cross":   row["signal_btc_cross"] or None,
            "signal_ndx_cross":   row["signal_ndx_cross"] or None,
            "composite_btc":      row["composite_btc"] or None,
            "composite_ndx":      row["composite_ndx"] or None,
        })

    summary = {
        "corr_btc_24m":  round(_safe_float(last["corr_btc_24m"], 0), 3) if _safe_float(last["corr_btc_24m"]) is not None else None,
        "corr_ndx_24m":  round(_safe_float(last["corr_ndx_24m"], 0), 3) if _safe_float(last["corr_ndx_24m"]) is not None else None,
        "composite_btc": last["composite_btc"] or "NEUTRE",
        "composite_ndx": last["composite_ndx"] or "NEUTRE",
    }

    return summary, correlation_data


# ============================================================
# ECONOMIC CALENDAR (dynamic from FRED releases)
# ============================================================

def _fred_latest_obs(series_id, n=6):
    """Fetch the latest N observations for a FRED series. Returns list of (date, value)."""
    import requests as _req
    try:
        url = (
            f"https://api.stlouisfed.org/fred/series/observations"
            f"?series_id={series_id}&api_key={FRED_API_KEY}&file_type=json"
            f"&sort_order=desc&limit={n}"
        )
        resp = _req.get(url, timeout=8)
        if resp.status_code != 200:
            return []
        obs = resp.json().get("observations", [])
        return [(o["date"], o["value"]) for o in obs if o["value"] != "."]
    except Exception:
        return []


def _get_economic_calendar():
    """Return key US economic events for current + next 2 weeks.
    Uses FRED release/dates for scheduling and series/observations for actual values.
    """
    from datetime import date, timedelta
    import requests as _req

    today = date.today()
    api_key = FRED_API_KEY

    # ---- Release map: release_id -> event metadata + FRED series for values ----
    # series_id: primary series to fetch Previous/Actual values
    # fmt: how to display the value (delta = month-over-month change, pct = %, raw = as-is, k = thousands)
    RELEASE_MAP = {
        10:  {"event": "CPI (Consumer Price Index)",     "impact": "high",   "time": "08:30 ET", "category": "inflation",
              "series": "CPIAUCSL", "fmt": "pct_chg", "unit": "% YoY"},
        21:  {"event": "PPI (Producer Price Index)",     "impact": "medium", "time": "08:30 ET", "category": "inflation",
              "series": "PPIACO",   "fmt": "pct_chg", "unit": "% YoY"},
        46:  {"event": "ISM Manufacturing PMI",          "impact": "high",   "time": "10:00 ET", "category": "manufacturing",
              "series": None,       "fmt": "index",   "unit": ""},
        29:  {"event": "ISM Services PMI",               "impact": "high",   "time": "10:00 ET", "category": "services",
              "series": None,       "fmt": "index",   "unit": ""},
        50:  {"event": "Employment Situation (NFP)",     "impact": "high",   "time": "08:30 ET", "category": "employment",
              "series": "PAYEMS",   "fmt": "delta_k", "unit": "K"},
        9:   {"event": "Retail Sales",                   "impact": "high",   "time": "08:30 ET", "category": "consumer",
              "series": "RSAFS",    "fmt": "pct_chg_mom", "unit": "% MoM"},
        19:  {"event": "Consumer Sentiment (UMich)",     "impact": "medium", "time": "10:00 ET", "category": "consumer",
              "series": "UMCSENT",  "fmt": "raw",     "unit": ""},
        53:  {"event": "GDP (Advance Estimate)",         "impact": "high",   "time": "08:30 ET", "category": "growth",
              "series": "GDP",      "fmt": "pct_chg", "unit": "% QoQ"},
        309: {"event": "FOMC Statement / Minutes",       "impact": "high",   "time": "14:00 ET", "category": "fed",
              "series": "FEDFUNDS", "fmt": "raw_pct", "unit": "%"},
        11:  {"event": "Employment Cost Index",          "impact": "medium", "time": "08:30 ET", "category": "employment",
              "series": "ECIWAG",   "fmt": "raw",     "unit": "%"},
        175: {"event": "Initial Jobless Claims",         "impact": "medium", "time": "08:30 ET", "category": "employment",
              "series": "ICSA",     "fmt": "claims_k", "unit": "K"},
        13:  {"event": "Industrial Production",          "impact": "medium", "time": "09:15 ET", "category": "manufacturing",
              "series": "INDPRO",   "fmt": "pct_chg_mom", "unit": "% MoM"},
        18:  {"event": "Housing Starts",                 "impact": "medium", "time": "08:30 ET", "category": "housing",
              "series": "HOUST",    "fmt": "thousands", "unit": "K"},
        101: {"event": "JOLTS Job Openings",             "impact": "medium", "time": "10:00 ET", "category": "employment",
              "series": "JTSJOL",   "fmt": "thousands", "unit": "K"},
        37:  {"event": "ADP Employment Change",          "impact": "medium", "time": "08:15 ET", "category": "employment",
              "series": None,       "fmt": "delta_k", "unit": "K"},
    }

    # ---- 1. Get release dates using FRED release/dates ----
    window_start = (today - timedelta(days=7)).isoformat()
    window_end   = (today + timedelta(days=21)).isoformat()

    events = []

    # Releases that publish once per period (monthly/quarterly) — use with_no_data=true
    CLEAN_RELEASES = {10, 21, 50, 9, 53, 309, 11, 19}  # CPI, PPI, NFP, Retail, GDP, FOMC, ECI, UMich
    # Releases that have noisy daily dates — deduplicate to monthly
    NOISY_RELEASES = {46, 29, 175, 13, 18, 101, 37}    # ISM, Claims, IndProd, Housing, JOLTS, ADP

    for rid, info in RELEASE_MAP.items():
        try:
            if rid in CLEAN_RELEASES:
                url = (
                    f"https://api.stlouisfed.org/fred/release/dates"
                    f"?release_id={rid}&api_key={api_key}&file_type=json"
                    f"&include_release_dates_with_no_data=true"
                    f"&sort_order=desc&limit=10"
                )
            else:
                url = (
                    f"https://api.stlouisfed.org/fred/release/dates"
                    f"?release_id={rid}&api_key={api_key}&file_type=json"
                    f"&include_release_dates_with_no_data=false"
                    f"&sort_order=desc&limit=200"
                )
            resp = _req.get(url, timeout=5)
            if resp.status_code != 200:
                continue
            data = resp.json()
            all_dates = sorted(set(rd["date"] for rd in data.get("release_dates", [])))

            # For noisy releases: deduplicate to first date per month
            if rid in NOISY_RELEASES:
                monthly = {}
                for d in all_dates:
                    ym = d[:7]  # YYYY-MM
                    if ym not in monthly:
                        monthly[ym] = d
                all_dates = sorted(monthly.values())

            # Pick: most recent past (within 7 days) + next 2 future (within 21 days)
            past_dates = [d for d in all_dates if d <= today.isoformat() and d >= window_start]
            future_dates = [d for d in all_dates if d > today.isoformat() and d <= window_end]

            dates_to_show = []
            if past_dates:
                dates_to_show.append(past_dates[-1])  # most recent past
            dates_to_show.extend(future_dates[:2])  # up to 2 future

            for d in dates_to_show:
                events.append({
                    "date": d,
                    "time": info["time"],
                    "event": info["event"],
                    "impact": info["impact"],
                    "previous": "—",
                    "forecast": "—",
                    "actual": "—",
                    "category": info["category"],
                    "_series": info.get("series"),
                    "_fmt": info.get("fmt", "raw"),
                    "_unit": info.get("unit", ""),
                    "_is_past": d <= today.isoformat(),
                })
        except Exception:
            continue

    # ---- 1b. Add scheduled events that FRED release/dates doesn't cover well ----
    # Jobless Claims: every Thursday
    # FOMC: known 2026 meeting dates
    # UMich Consumer Sentiment: mid-month Friday (preliminary) + end-month Friday (final)
    from datetime import date as _date

    def _next_weekday(start, weekday, count=4):
        """Return the next `count` occurrences of `weekday` (0=Mon...6=Sun) from `start`."""
        results = []
        d = start
        while len(results) < count:
            if d.weekday() == weekday:
                results.append(d)
            d += timedelta(days=1)
        return results

    # Jobless Claims: every Thursday in window
    thursdays = _next_weekday(today - timedelta(days=7), 3, count=4)
    for th in thursdays:
        th_str = th.isoformat()
        if window_start <= th_str <= window_end:
            events.append({
                "date": th_str,
                "time": "08:30 ET",
                "event": "Initial Jobless Claims",
                "impact": "medium",
                "previous": "—", "forecast": "—", "actual": "—",
                "category": "employment",
                "_series": "ICSA", "_fmt": "claims_k", "_unit": "K",
                "_is_past": th_str <= today.isoformat(),
            })

    # FOMC 2026 meeting dates (statement release dates)
    fomc_2026 = ["2026-01-29", "2026-03-18", "2026-05-06", "2026-06-17",
                 "2026-07-29", "2026-09-16", "2026-11-04", "2026-12-16"]
    for fd in fomc_2026:
        if window_start <= fd <= window_end:
            events.append({
                "date": fd,
                "time": "14:00 ET",
                "event": "FOMC Statement",
                "impact": "high",
                "previous": "—", "forecast": "—", "actual": "—",
                "category": "fed",
                "_series": "FEDFUNDS", "_fmt": "raw_pct", "_unit": "%",
                "_is_past": fd <= today.isoformat(),
            })

    # UMich Consumer Sentiment: ~2nd Friday (preliminary) and ~4th Friday (final)
    # Approximate: 10th-16th (prelim) and 24th-end (final) of each month
    import calendar
    for month_offset in [-1, 0, 1]:
        m = today.month + month_offset
        y = today.year
        if m < 1: m += 12; y -= 1
        if m > 12: m -= 12; y += 1
        # Find 2nd and 4th Friday
        fridays = [_date(y, m, d) for d in range(1, calendar.monthrange(y, m)[1] + 1) if _date(y, m, d).weekday() == 4]
        if len(fridays) >= 2:
            prelim = fridays[1]  # 2nd Friday
            if window_start <= prelim.isoformat() <= window_end:
                events.append({
                    "date": prelim.isoformat(),
                    "time": "10:00 ET",
                    "event": "Consumer Sentiment (UMich) — Prelim",
                    "impact": "medium",
                    "previous": "—", "forecast": "—", "actual": "—",
                    "category": "consumer",
                    "_series": "UMCSENT", "_fmt": "raw", "_unit": "",
                    "_is_past": prelim.isoformat() <= today.isoformat(),
                })
        if len(fridays) >= 4:
            final = fridays[3]  # 4th Friday
            if window_start <= final.isoformat() <= window_end:
                events.append({
                    "date": final.isoformat(),
                    "time": "10:00 ET",
                    "event": "Consumer Sentiment (UMich) — Final",
                    "impact": "medium",
                    "previous": "—", "forecast": "—", "actual": "—",
                    "category": "consumer",
                    "_series": "UMCSENT", "_fmt": "raw", "_unit": "",
                    "_is_past": final.isoformat() <= today.isoformat(),
                })

    # Deduplicate (same event+date)
    seen = set()
    deduped = []
    for ev in events:
        key = (ev["event"].split(" —")[0].split(" (")[0].strip(), ev["date"])
        if key not in seen:
            seen.add(key)
            deduped.append(ev)
    events = deduped

    # ---- 2. Enrich with FRED series data (previous + actual) ----
    # Batch: group by series to avoid duplicate API calls
    series_cache = {}
    for ev in events:
        sid = ev.get("_series")
        if not sid or sid in series_cache:
            continue
        obs = _fred_latest_obs(sid, n=6)
        series_cache[sid] = obs

    def _avg_vals(observations, count=3):
        """Average the first `count` float values from observations."""
        vals = [float(o[1]) for o in observations[:count] if o[1] not in (".", "")]
        return sum(vals) / len(vals) if vals else None

    for ev in events:
        sid = ev.get("_series")
        if not sid or sid not in series_cache:
            continue
        obs = series_cache[sid]
        if len(obs) < 2:
            continue

        fmt = ev["_fmt"]
        try:
            if fmt == "pct_chg":  # Year-over-year % change (CPI, PPI, GDP)
                latest_val = float(obs[0][1])
                prev_val = float(obs[1][1])
                ev["previous"] = f"{prev_val:,.1f}"
                ev["actual"] = f"{latest_val:,.1f}" if ev["_is_past"] else "—"
                # Forecast: average of last 3 values
                avg = _avg_vals(obs, 3)
                if avg is not None:
                    ev["forecast"] = f"{avg:,.1f}"

            elif fmt == "pct_chg_mom":  # Month-over-month % change (Retail, IndProd)
                latest_val = float(obs[0][1])
                prev_val = float(obs[1][1])
                if prev_val != 0:
                    mom = ((latest_val - prev_val) / prev_val) * 100
                    prev_prev = float(obs[2][1]) if len(obs) >= 3 else prev_val
                    prev_mom = ((prev_val - prev_prev) / prev_prev) * 100 if prev_prev != 0 else 0
                    ev["previous"] = f"{prev_mom:+.1f}%"
                    ev["actual"] = f"{mom:+.1f}%" if ev["_is_past"] else "—"
                    # Forecast: average of last 3 MoM changes
                    moms = []
                    for i in range(min(3, len(obs) - 1)):
                        v0, v1 = float(obs[i][1]), float(obs[i+1][1])
                        if v1 != 0:
                            moms.append(((v0 - v1) / v1) * 100)
                    if moms:
                        ev["forecast"] = f"{sum(moms)/len(moms):+.1f}%"

            elif fmt == "delta_k":  # Month-over-month delta in thousands (NFP)
                latest_val = float(obs[0][1])
                prev_val = float(obs[1][1])
                delta = latest_val - prev_val
                if len(obs) >= 3:
                    prev_delta = prev_val - float(obs[2][1])
                    ev["previous"] = f"{prev_delta:+,.0f}K"
                else:
                    ev["previous"] = "—"
                ev["actual"] = f"{delta:+,.0f}K" if ev["_is_past"] else "—"
                # Forecast: average of last 3 deltas
                deltas = []
                for i in range(min(3, len(obs) - 1)):
                    deltas.append(float(obs[i][1]) - float(obs[i+1][1]))
                if deltas:
                    ev["forecast"] = f"{sum(deltas)/len(deltas):+,.0f}K"

            elif fmt == "raw_k":  # Raw value, display as-is with comma
                latest_val = float(obs[0][1])
                prev_val = float(obs[1][1])
                ev["previous"] = f"{prev_val:,.0f}"
                if ev["_is_past"]:
                    ev["actual"] = f"{latest_val:,.0f}"
                avg = _avg_vals(obs, 3)
                if avg is not None:
                    ev["forecast"] = f"{avg:,.0f}"

            elif fmt == "claims_k":  # Claims: raw value (e.g. 213000) -> display as "213K"
                latest_val = float(obs[0][1])
                prev_val = float(obs[1][1])
                ev["previous"] = f"{prev_val/1000:,.0f}K"
                if ev["_is_past"]:
                    ev["actual"] = f"{latest_val/1000:,.0f}K"
                avg = _avg_vals(obs, 3)
                if avg is not None:
                    ev["forecast"] = f"{avg/1000:,.0f}K"

            elif fmt == "thousands":  # Value already in thousands (e.g. JOLTS 6542 -> "6,542K")
                latest_val = float(obs[0][1])
                prev_val = float(obs[1][1])
                ev["previous"] = f"{prev_val:,.0f}K"
                if ev["_is_past"]:
                    ev["actual"] = f"{latest_val:,.0f}K"
                avg = _avg_vals(obs, 3)
                if avg is not None:
                    ev["forecast"] = f"{avg:,.0f}K"

            elif fmt == "raw_pct":  # Raw percentage (FEDFUNDS)
                latest_val = float(obs[0][1])
                prev_val = float(obs[1][1])
                ev["previous"] = f"{prev_val:.2f}%"
                ev["actual"] = f"{latest_val:.2f}%" if ev["_is_past"] else "—"
                # Forecast: latest value (Fed rates are sticky)
                ev["forecast"] = f"{latest_val:.2f}%"

            elif fmt == "raw" or fmt == "index":  # Raw number (UMich, ECI)
                latest_val = float(obs[0][1])
                prev_val = float(obs[1][1])
                ev["previous"] = f"{prev_val:,.1f}"
                ev["actual"] = f"{latest_val:,.1f}" if ev["_is_past"] else "—"
                avg = _avg_vals(obs, 3)
                if avg is not None:
                    ev["forecast"] = f"{avg:,.1f}"

        except (ValueError, ZeroDivisionError, IndexError):
            pass

    # ---- 3. Clean up internal fields ----
    for ev in events:
        ev.pop("_series", None)
        ev.pop("_fmt", None)
        ev.pop("_unit", None)
        ev.pop("_is_past", None)
        ev["is_today"] = (ev["date"] == today.isoformat())

    # Sort by date, then time
    events.sort(key=lambda e: (e["date"], e["time"]))

    # Fallback if FRED API failed entirely
    if not events:
        return _get_static_calendar()

    return events


def _get_static_calendar():
    """Fallback static calendar when FRED API is unavailable."""
    from datetime import date, timedelta
    today = date.today()
    monday = today - timedelta(days=today.weekday())
    return [
        {"date": monday.isoformat(), "time": "10:00 ET", "event": "ISM Manufacturing PMI",
         "impact": "high", "previous": "—", "forecast": "—", "actual": "—", "category": "manufacturing"},
        {"date": (monday + timedelta(days=2)).isoformat(), "time": "08:15 ET", "event": "ADP Employment Change",
         "impact": "medium", "previous": "—", "forecast": "—", "actual": "—", "category": "employment"},
        {"date": (monday + timedelta(days=3)).isoformat(), "time": "08:30 ET", "event": "Initial Jobless Claims",
         "impact": "medium", "previous": "—", "forecast": "—", "actual": "—", "category": "employment"},
        {"date": (monday + timedelta(days=4)).isoformat(), "time": "08:30 ET", "event": "Non-Farm Payrolls (NFP)",
         "impact": "high", "previous": "—", "forecast": "—", "actual": "—", "category": "employment"},
    ]


# ============================================================
# PUBLIC API: fetch_vulnerability_dashboard
# ============================================================

_cache = {"data": None, "timestamp": None}

def fetch_vulnerability_dashboard(force_refresh=False):
    """
    Main entry point. Returns the full macro dashboard payload:
    - global_score, regime, regime_color
    - sub_scores (4 items with name, score, weight, color, kpis)
    - history (12 months)
    - alerts
    - correlation_summary
    - correlation_history (last 24 months)
    - calendar (economic events)
    """
    # Cache for 1 hour to avoid hammering FRED
    import time
    now = time.time()
    if not force_refresh and _cache["data"] and _cache["timestamp"] and (now - _cache["timestamp"]) < 3600:
        return _cache["data"]

    print("[data_macro] Fetching FRED data...")
    raw = {}
    for key, sid in FRED_SERIES.items():
        series = _fetch_fred(sid, FRED_API_KEY)
        if series is not None:
            raw[key] = series

    if len(raw) < 5:
        print("[data_macro] FRED API returned too few series, using fallback data")
        raw = _get_fallback_data()
    else:
        # Transform CPI index values to YoY % change
        if "cpi_yoy" in raw:
            cpi_yoy = _compute_yoy_pct(raw["cpi_yoy"])
            if cpi_yoy is not None:
                raw["cpi_yoy"] = cpi_yoy
            else:
                print("[data_macro] CPI YoY calculation failed, keeping raw")
        if "core_cpi_yoy" in raw:
            core_cpi_yoy = _compute_yoy_pct(raw["core_cpi_yoy"])
            if core_cpi_yoy is not None:
                raw["core_cpi_yoy"] = core_cpi_yoy
            else:
                print("[data_macro] Core CPI YoY calculation failed, keeping raw")
        # Transform deficit from raw monthly millions to deficit/GDP ratio %
        if "deficit_gdp" in raw:
            deficit_ratio = _compute_deficit_gdp_ratio(raw["deficit_gdp"], FRED_API_KEY)
            if deficit_ratio is not None:
                raw["deficit_gdp"] = deficit_ratio
            else:
                print("[data_macro] Deficit/GDP ratio calculation failed, using fallback")
                # Provide a reasonable fallback series
                months = raw["deficit_gdp"].index[-12:]
                raw["deficit_gdp"] = pd.Series([6.5]*len(months), index=months)
        # Transform HY Spread from percentage points to basis points
        if "hy_spread" in raw:
            raw["hy_spread"] = raw["hy_spread"] * 100  # 3.1% → 310 bps
        if "ccc_oas" in raw:
            raw["ccc_oas"] = raw["ccc_oas"] * 100  # 9.44% → 944 bps
        # Transform productivity index to YoY % change (quarterly data)
        if "productivity" in raw and len(raw["productivity"]) >= 5:
            prod_yoy = raw["productivity"].pct_change(periods=4) * 100
            prod_yoy = prod_yoy.dropna()
            if len(prod_yoy) > 0:
                raw["productivity"] = prod_yoy
            else:
                print("[data_macro] Productivity YoY calculation failed")

    # Compute scores
    score_records = _compute_scores(raw)
    latest = score_records[-1]
    prev = score_records[-2] if len(score_records) > 1 else latest

    gs = latest["GlobalScore"]
    gs_prev = prev["GlobalScore"]
    gs_delta = round(gs - gs_prev, 1)

    # Sub-scores with KPIs
    sub_scores = [
        {
            "name": "Dette & Fiscal",
            "score": latest["DebtScore"],
            "weight": "35%",
            "color": _regime_color(latest["DebtScore"]),
            "kpis": [
                {"label": "Debt/GDP", "value": f"{latest['debt_gdp']:.1f}%", "alert": latest["debt_gdp"] > 110},
                {"label": "Deficit/GDP", "value": f"{latest['deficit_gdp']:.1f}%", "alert": latest["deficit_gdp"] > 7},
                {"label": "HY Spread", "value": f"{latest['hy_spread']:.0f} bps", "alert": latest["hy_spread"] > 400},
            ]
        },
        {
            "name": "Prix & USD",
            "score": latest["PriceFXScore"],
            "weight": "25%",
            "color": _regime_color(latest["PriceFXScore"]),
            "kpis": [
                {"label": "CPI YoY", "value": f"{latest['cpi_yoy']:.1f}%", "alert": latest["cpi_yoy"] > 3},
                {"label": "Core CPI", "value": f"{latest['core_cpi_yoy']:.1f}%", "alert": latest["core_cpi_yoy"] > 3},
                {"label": "DXY", "value": f"{latest['dxy']:.1f}", "alert": False},
            ]
        },
        {
            "name": "Emploi & Social",
            "score": latest["JobsScore"],
            "weight": "20%",
            "color": _regime_color(latest["JobsScore"]),
            "kpis": [
                {"label": "U-3", "value": f"{latest['u3']:.1f}%", "alert": latest["u3"] > 4.5},
                {"label": "U-6", "value": f"{latest['u6']:.1f}%", "alert": latest["u6"] > 8},
                {"label": "Participation", "value": f"{latest['participation']:.1f}%", "alert": latest["participation"] < 63},
            ]
        },
        {
            "name": "IA & Productivité",
            "score": latest["IAScore"],
            "weight": "20%",
            "color": _regime_color(latest["IAScore"]),
            "kpis": [
                {"label": "Productivité", "value": f"{latest['productivity']:.1f}%", "alert": latest["productivity"] < 1.5},
                {"label": "Durée chômage", "value": f"{latest['unemp_duration']:.0f} sem.", "alert": latest["unemp_duration"] > 25},
            ]
        },
    ]

    # Alerts
    alerts = []
    if latest["debt_gdp"] > 110:
        alerts.append({"level": "HAUT RISQUE", "type": "danger", "text": f"Dette fédérale {latest['debt_gdp']:.0f}% du PIB, trajectoire non soutenable"})
    if latest["cpi_yoy"] > 3:
        alerts.append({"level": "SURVEILLANCE", "type": "warning", "text": f"CPI à {latest['cpi_yoy']:.1f}%, au-dessus de la cible Fed de 2%"})
    if latest["u3"] > 4.5:
        alerts.append({"level": "ATTENTION", "type": "warning", "text": f"Chômage U-3 en hausse à {latest['u3']:.1f}%"})
    if latest["hy_spread"] < 400:
        alerts.append({"level": "POSITIF", "type": "success", "text": f"Spreads HY stables ({latest['hy_spread']:.0f} bps), pas de stress crédit"})
    if latest["productivity"] >= 1.5:
        alerts.append({"level": "POSITIF", "type": "success", "text": f"Productivité {latest['productivity']:.1f}% YoY, soutenue par adoption IA"})

    # Correlations
    corr_summary, corr_history = _compute_correlation_signals(score_records)

    # Calendar
    calendar = _get_economic_calendar()

    # ---- Risk-On / Risk-Off regime based on HY Spread ----
    hy = latest["hy_spread"]
    # Compute 30-day HY spread change from history
    hy_history = [r.get("hy_spread", hy) for r in score_records if r.get("hy_spread") is not None]
    hy_prev_30d = hy_history[-2] if len(hy_history) >= 2 else hy
    hy_delta = hy - hy_prev_30d
    if hy < 300:
        risk_regime_label = "RISK-ON"
        risk_regime_color = "#70AD47"
        risk_regime_score = max(0, min(100, (300 - hy) / 2))  # 0-100, higher = more risk-on
    elif hy < 400:
        risk_regime_label = "NEUTRE"
        risk_regime_color = "#FFD966"
        risk_regime_score = 50 - (hy - 300) / 4  # 50 -> 25
    elif hy < 500:
        risk_regime_label = "RISK-OFF"
        risk_regime_color = "#F4B942"
        risk_regime_score = 25 - (hy - 400) / 8  # 25 -> 12.5
    else:
        risk_regime_label = "STRESS"
        risk_regime_color = "#C00000"
        risk_regime_score = max(0, 12.5 - (hy - 500) / 40)

    # ---- CCC OAS stress indicator ----
    ccc = latest.get("ccc_oas", 900)
    ccc_history = [r.get("ccc_oas", ccc) for r in score_records if r.get("ccc_oas") is not None]
    ccc_prev_30d = ccc_history[-2] if len(ccc_history) >= 2 else ccc
    ccc_delta = ccc - ccc_prev_30d
    # CCC stress zones per user's trading rules
    if ccc < 700:
        ccc_label = "SAIN"
        ccc_color = "#70AD47"
    elif ccc < 868:
        ccc_label = "ATTENTION"
        ccc_color = "#FFD966"
    elif ccc < 944:
        ccc_label = "STRESS NAISSANT"
        ccc_color = "#F4B942"
    elif ccc < 1050:
        ccc_label = "STRESS MOD\u00c9R\u00c9"
        ccc_color = "#E05D6A"
    elif ccc < 1100:
        ccc_label = "RISK-OFF TOTAL"
        ccc_color = "#C00000"
    else:
        ccc_label = "CRISE CCC"
        ccc_color = "#8B0000"

    risk_regime = {
        "label": risk_regime_label,
        "color": risk_regime_color,
        "score": round(risk_regime_score, 1),
        "hy_spread": round(hy, 0),
        "hy_delta_30d": round(hy_delta, 0),
        "thresholds": {
            "risk_on": "< 300 bps",
            "neutral": "300\u2013400 bps",
            "risk_off": "400\u2013500 bps",
            "stress": "> 500 bps",
        },
        "ccc_oas": round(ccc, 0),
        "ccc_delta_30d": round(ccc_delta, 0),
        "ccc_label": ccc_label,
        "ccc_color": ccc_color,
        "ccc_thresholds": {
            "sain": "< 700 bps",
            "attention": "700\u2013868 bps",
            "stress_naissant": "868\u2013944 bps",
            "stress_modere": "944\u20131050 bps",
            "risk_off_total": "1050\u20131100 bps",
            "crise": "> 1100 bps",
        },
    }

    result = {
        "updated_at": datetime.utcnow().isoformat(),
        "global_score": gs,
        "global_score_delta": gs_delta,
        "regime": _regime_label(gs),
        "regime_color": _regime_color(gs),
        "sub_scores": sub_scores,
        "history": score_records,
        "alerts": alerts,
        "correlation_summary": corr_summary,
        "correlation_history": corr_history,
        "calendar": calendar,
        "weights": {
            "dette_fiscal": "35%",
            "prix_usd": "25%",
            "emploi_social": "20%",
            "ia_productivite": "20%",
        },
        "source": "FRED (Federal Reserve Bank of St. Louis)",
        "risk_regime": risk_regime,
    }

    _cache["data"] = result
    _cache["timestamp"] = now

    return result
