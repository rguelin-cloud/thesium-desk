"""
data_geopolitical.py — Geopolitical Risk Indicator for Nextones Desk
Sources:
  - GDELT GKG API (free, no key) — conflict intensity, tone, article counts
  - USGS Earthquake API (free) — infrastructure risk (significant quakes)
  - Static chokepoint / theater risk model

Produces a composite Geopolitical Risk Score (0–100) with sub-components:
  1. Conflict Intensity (GDELT event tone + volume)
  2. Supply Chain Risk (chokepoint disruption proxy)
  3. Threat Level by Theater (regional breakdown)
  4. Infrastructure Risk (seismic + natural disasters)

GDELT rate-limit strategy:
  - Strict 1 request per 5 seconds → we enforce 6s minimum between calls
  - Global lock ensures sequential access
  - Queries consolidated: 3 conflict→1, 6 chokepoints→2, 5 theaters→2 = ~5 GDELT calls
  - Background pre-fetch at startup so users never wait
  - 0-result responses are NOT cached (may be rate-limit artifacts)
"""

import json
import math
import threading
import time as _time
import traceback
from datetime import datetime, timedelta
from typing import Any

import requests

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

GDELT_GKG_API = "https://api.gdeltproject.org/api/v2/doc/doc"
USGS_EARTHQUAKE_API = "https://earthquake.usgs.gov/fdsnws/event/1/query"

# Strategic chokepoints with baseline risk and keywords for monitoring
CHOKEPOINTS = {
    "Strait of Hormuz": {
        "baseline_risk": 55,
        "keywords": ["hormuz", "iran", "persian gulf", "oil tanker"],
        "impact": "~20% of global oil transit",
    },
    "Strait of Malacca": {
        "baseline_risk": 30,
        "keywords": ["malacca", "south china sea", "singapore strait"],
        "impact": "~25% of global trade",
    },
    "Suez Canal": {
        "baseline_risk": 45,
        "keywords": ["suez", "red sea", "houthi", "bab el-mandeb"],
        "impact": "~12% of global trade",
    },
    "Bab el-Mandeb": {
        "baseline_risk": 60,
        "keywords": ["bab el-mandeb", "yemen", "houthi", "red sea attack"],
        "impact": "Gateway to Suez Canal",
    },
    "Panama Canal": {
        "baseline_risk": 25,
        "keywords": ["panama canal", "drought panama", "canal transit"],
        "impact": "~5% of global trade",
    },
    "Taiwan Strait": {
        "baseline_risk": 40,
        "keywords": ["taiwan strait", "taiwan china", "semiconductor"],
        "impact": "Semiconductor supply chain",
    },
}

# Theaters for regional risk assessment
THEATERS = {
    "Middle East": {
        "keywords": ["iran", "israel", "gaza", "houthi", "yemen", "syria", "iraq", "lebanon", "hezbollah"],
        "weight": 0.30,
    },
    "East Asia": {
        "keywords": ["taiwan", "china military", "north korea", "south china sea", "philippines"],
        "weight": 0.25,
    },
    "Eastern Europe": {
        "keywords": ["ukraine", "russia", "nato", "baltic", "crimea", "donbas"],
        "weight": 0.25,
    },
    "Africa / Sahel": {
        "keywords": ["sahel", "niger", "mali", "sudan", "ethiopia", "coup"],
        "weight": 0.10,
    },
    "Latin America": {
        "keywords": ["venezuela", "colombia cartel", "brazil", "mexico violence", "latin america"],
        "weight": 0.10,
    },
}

# ---------------------------------------------------------------------------
# Cache (thread-safe)
# ---------------------------------------------------------------------------
_cache: dict[str, Any] = {}
_cache_ts: dict[str, float] = {}
_cache_lock = threading.Lock()
CACHE_TTL = 1800  # 30 minutes

# Global GDELT rate limiter — ensures 6s minimum between any GDELT call
_gdelt_lock = threading.Lock()
_gdelt_last_call: float = 0.0

# Background fetch status
_bg_fetch_done = threading.Event()
_bg_fetch_started = False


def _is_cached(key: str) -> bool:
    with _cache_lock:
        return key in _cache and (datetime.now().timestamp() - _cache_ts.get(key, 0)) < CACHE_TTL


def _set_cache(key: str, value: Any):
    with _cache_lock:
        _cache[key] = value
        _cache_ts[key] = datetime.now().timestamp()


def _get_cache(key: str) -> Any:
    with _cache_lock:
        return _cache.get(key)


# ---------------------------------------------------------------------------
# GDELT GKG API — rate-limited
# ---------------------------------------------------------------------------

def _query_gdelt(query: str, mode: str = "artlist", maxrecords: int = 75,
                 timespan: str = "7d", sourcelang: str = "eng") -> dict:
    """Query GDELT DOC 2.0 API with global rate limiting.
    Enforces 6s between any two GDELT calls. Does NOT cache 0-result responses.
    Retries up to 3 times on 429 with exponential backoff.
    """
    cache_key = f"gdelt_{query}_{mode}_{timespan}"
    if _is_cached(cache_key):
        return _get_cache(cache_key)

    # GDELT requires OR'd terms to be wrapped in parentheses
    q = f"({query})" if " OR " in query else query
    params = {
        "query": q,
        "mode": mode,
        "maxrecords": maxrecords,
        "timespan": timespan,
        "format": "json",
        "sourcelang": sourcelang,
    }

    global _gdelt_last_call
    max_retries = 3

    for attempt in range(max_retries):
        # Acquire the global GDELT lock and enforce delay
        with _gdelt_lock:
            now = _time.time()
            # Base delay: 6s for first attempt, 10s for retry, 15s for third
            min_delay = 6.0 + (attempt * 5.0)
            elapsed = now - _gdelt_last_call
            if elapsed < min_delay:
                wait = min_delay - elapsed
                print(f"[GDELT] Throttle: waiting {wait:.1f}s (attempt {attempt+1}) for: {q[:60]}...")
                _time.sleep(wait)

            _gdelt_last_call = _time.time()

            try:
                resp = requests.get(GDELT_GKG_API, params=params, timeout=20)

                if resp.status_code == 429:
                    print(f"[GDELT] 429 rate limit (attempt {attempt+1}/{max_retries}) for: {q[:60]}")
                    # Don't update last_call timestamp — the request was rejected
                    if attempt < max_retries - 1:
                        continue  # Will retry with longer delay
                    else:
                        print(f"[GDELT] All retries exhausted for: {q[:60]}")
                        return {}

                if resp.status_code == 200:
                    # Safely parse JSON
                    try:
                        data = resp.json()
                    except Exception:
                        print(f"[GDELT] JSON parse error for: {q[:60]}")
                        return {}

                    # Only cache if we got actual data (not empty from rate limiting)
                    has_data = False
                    if mode == "tonechart":
                        has_data = len(data.get("tonechart", [])) > 0
                    elif mode == "artlist":
                        has_data = len(data.get("articles", [])) > 0
                    else:
                        has_data = True

                    if has_data:
                        _set_cache(cache_key, data)
                        print(f"[GDELT] OK ({mode}): {q[:50]}... → cached")
                    else:
                        print(f"[GDELT] Empty result for '{q[:50]}' — not caching")
                    return data
                else:
                    print(f"[GDELT] HTTP {resp.status_code} for '{q[:60]}'")
                    return {}

            except requests.exceptions.Timeout:
                print(f"[GDELT] Timeout (attempt {attempt+1}) for: {q[:60]}")
                if attempt < max_retries - 1:
                    continue
            except Exception:
                traceback.print_exc()
                return {}

    return {}


def _get_gdelt_tone_volume(query: str, timespan: str = "7d", fetch_articles: bool = False) -> dict:
    """Get article count and average tone for a GDELT query.
    Uses tonechart mode which provides both count and tone distribution.
    Returns: {"count": int, "avg_tone": float, "articles": [...]}
    """
    # Use tonechart for both count and tone data (more efficient)
    tone_data = _query_gdelt(query, mode="tonechart", maxrecords=100, timespan=timespan)
    tone_bins = tone_data.get("tonechart", [])

    avg_tone = 0.0
    total_count = 0
    if tone_bins:
        weighted_tone = 0.0
        for b in tone_bins:
            bin_val = b.get("bin", 0)
            bin_count = b.get("count", 0)
            if bin_count > 0:
                weighted_tone += bin_val * bin_count
                total_count += bin_count
        if total_count > 0:
            avg_tone = weighted_tone / total_count

    # Get articles for display only if explicitly requested
    articles = []
    if fetch_articles and total_count > 0:
        art_data = _query_gdelt(query, mode="artlist", maxrecords=5, timespan=timespan)
        articles = art_data.get("articles", [])[:5]

    return {
        "count": total_count,
        "avg_tone": round(avg_tone, 2),
        "articles": articles,
    }


# ---------------------------------------------------------------------------
# Conflict Intensity Score (0–100)
# ---------------------------------------------------------------------------

def _compute_conflict_intensity() -> dict:
    """
    Uses GDELT to measure global conflict tone and volume.
    More negative tone + higher volume = higher conflict intensity.
    OPTIMIZED: single combined query instead of 3 separate ones.
    """
    # Combine all conflict terms into a single OR query
    combined_query = "military conflict OR attack bombing OR war escalation OR sanctions embargo OR missile strike OR drone terrorism"
    result = _get_gdelt_tone_volume(combined_query, timespan="7d")

    total_count = result["count"]
    avg_tone = result["avg_tone"]

    # Scoring logic:
    # Tone range: typically -10 (very negative) to +10 (very positive)
    # More negative = higher risk
    # Volume: more articles about conflict = higher risk
    tone_score = max(0, min(100, 50 + (-avg_tone) * 8))  # Center at 50, scale by tone

    # Volume factor: if > 200 articles about conflict in 7 days, bump up
    volume_factor = min(1.5, 1.0 + (total_count / 500))

    raw_score = tone_score * volume_factor
    score = max(0, min(100, raw_score))

    return {
        "score": round(score, 1),
        "avg_tone": round(avg_tone, 2),
        "article_count": total_count,
        "detail": f"Tone moy.: {avg_tone:.1f} | {total_count} articles conflict 7j",
    }


# ---------------------------------------------------------------------------
# Supply Chain / Chokepoint Risk (0–100)
# ---------------------------------------------------------------------------

def _compute_chokepoint_risk() -> dict:
    """
    Monitor strategic chokepoints via GDELT keyword searches.
    OPTIMIZED: 2 batched queries instead of 6 individual ones.
    Group A: Hormuz + Suez + Bab el-Mandeb (Middle East maritime)
    Group B: Malacca + Panama + Taiwan (Asia-Pacific + Americas)
    Individual scores estimated from combined results + baselines.
    """
    # Group A: Middle East maritime chokepoints
    group_a_names = ["Strait of Hormuz", "Suez Canal", "Bab el-Mandeb"]
    group_a_kw = []
    for name in group_a_names:
        group_a_kw.extend(CHOKEPOINTS[name]["keywords"][:2])
    group_a_query = " OR ".join(list(set(group_a_kw)))
    group_a_result = _get_gdelt_tone_volume(group_a_query, timespan="7d")

    # Group B: Asia-Pacific + Americas
    group_b_names = ["Strait of Malacca", "Panama Canal", "Taiwan Strait"]
    group_b_kw = []
    for name in group_b_names:
        group_b_kw.extend(CHOKEPOINTS[name]["keywords"][:2])
    group_b_query = " OR ".join(list(set(group_b_kw)))
    group_b_result = _get_gdelt_tone_volume(group_b_query, timespan="7d")

    # Now distribute results to individual chokepoints
    chokepoint_scores = []
    for name, cp in CHOKEPOINTS.items():
        # Use group result for this chokepoint
        if name in group_a_names:
            group_result = group_a_result
            group_size = len(group_a_names)
        else:
            group_result = group_b_result
            group_size = len(group_b_names)

        # Proportional estimate: divide group count by number of chokepoints in group
        est_count = group_result["count"] // group_size
        est_tone = group_result["avg_tone"]

        # Base risk + event-driven adjustment
        event_factor = 0
        if est_count > 20:
            event_factor = min(25, est_count / 4)
        if est_tone < -3:
            event_factor += min(15, abs(est_tone) * 2)

        risk = min(100, cp["baseline_risk"] + event_factor)

        chokepoint_scores.append({
            "name": name,
            "risk": round(risk, 1),
            "baseline": cp["baseline_risk"],
            "article_count": est_count,
            "tone": est_tone,
            "impact": cp["impact"],
        })

    # Composite = weighted average (highest risks matter more)
    if chokepoint_scores:
        chokepoint_scores.sort(key=lambda x: x["risk"], reverse=True)
        top_risk = chokepoint_scores[0]["risk"]
        avg_rest = sum(c["risk"] for c in chokepoint_scores[1:]) / max(1, len(chokepoint_scores) - 1)
        composite = 0.4 * top_risk + 0.6 * avg_rest
    else:
        composite = 40

    return {
        "score": round(composite, 1),
        "chokepoints": chokepoint_scores,
    }


# ---------------------------------------------------------------------------
# Theater Threat Level (0–100)
# ---------------------------------------------------------------------------

def _compute_theater_risk() -> dict:
    """
    Regional threat assessment using GDELT keyword monitoring per theater.
    OPTIMIZED: 2 batched queries + individual parsing.
    Group 1: Middle East + Eastern Europe (high-weight, critical theaters)
    Group 2: East Asia + Africa/Sahel + Latin America
    Each theater gets its own query using top 4 keywords.
    To stay within rate limits we use 2 group queries and
    distribute proportionally based on keyword specificity.
    """
    theater_scores = []

    # We do individual queries for each theater but since we only have 5 theaters
    # and the global rate limiter handles timing, this is manageable.
    # Total: 5 queries × 6s = 30s (acceptable for background pre-fetch)
    for name, theater in THEATERS.items():
        query = " OR ".join(theater["keywords"][:4])
        result = _get_gdelt_tone_volume(query, timespan="7d", fetch_articles=False)

        # Score based on volume and negativity
        base = 30  # baseline
        if result["count"] > 500:
            base += min(30, result["count"] / 500)
        elif result["count"] > 100:
            base += min(20, result["count"] / 50)
        elif result["count"] > 0:
            base += min(10, result["count"] / 10)
        if result["avg_tone"] < -2:
            base += min(20, abs(result["avg_tone"]) * 3)

        score = min(100, base)
        theater_scores.append({
            "name": name,
            "score": round(score, 1),
            "weight": theater["weight"],
            "article_count": result["count"],
            "tone": result["avg_tone"],
            "top_articles": [
                {"title": a.get("title", ""), "url": a.get("url", ""), "date": a.get("seendate", "")}
                for a in result.get("articles", [])[:3]
            ],
        })

    # Weighted composite
    composite = sum(t["score"] * t["weight"] for t in theater_scores)

    return {
        "score": round(composite, 1),
        "theaters": theater_scores,
    }


# ---------------------------------------------------------------------------
# Infrastructure Risk (0–100) — Seismic + Natural Disasters
# ---------------------------------------------------------------------------

def _fetch_usgs_earthquakes() -> list:
    """Fetch significant earthquakes from USGS (last 30 days, mag >= 5.0)."""
    cache_key = "usgs_quakes"
    if _is_cached(cache_key):
        return _get_cache(cache_key)

    end = datetime.utcnow()
    start = end - timedelta(days=30)

    params = {
        "format": "geojson",
        "starttime": start.strftime("%Y-%m-%d"),
        "endtime": end.strftime("%Y-%m-%d"),
        "minmagnitude": 5.0,
        "orderby": "magnitude",
        "limit": 20,
    }
    try:
        resp = requests.get(USGS_EARTHQUAKE_API, params=params, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            quakes = []
            for f in data.get("features", []):
                props = f.get("properties", {})
                coords = f.get("geometry", {}).get("coordinates", [0, 0, 0])
                quakes.append({
                    "magnitude": props.get("mag", 0),
                    "place": props.get("place", "Unknown"),
                    "time": datetime.fromtimestamp(props.get("time", 0) / 1000).isoformat(),
                    "tsunami": props.get("tsunami", 0),
                    "lat": coords[1] if len(coords) > 1 else 0,
                    "lon": coords[0] if len(coords) > 0 else 0,
                    "depth": coords[2] if len(coords) > 2 else 0,
                })
            _set_cache(cache_key, quakes)
            return quakes
    except Exception:
        traceback.print_exc()

    return []


def _compute_infrastructure_risk() -> dict:
    """
    Infrastructure risk from natural disasters (earthquakes primarily).
    Score based on: count of significant quakes, max magnitude, tsunami warnings.
    """
    quakes = _fetch_usgs_earthquakes()

    if not quakes:
        return {
            "score": 15.0,
            "earthquake_count": 0,
            "max_magnitude": 0,
            "recent_quakes": [],
            "detail": "Aucune donnée sismique disponible",
        }

    max_mag = max(q["magnitude"] for q in quakes)
    tsunami_count = sum(1 for q in quakes if q.get("tsunami", 0) > 0)
    count = len(quakes)

    # Score: baseline 10 + magnitude factor + count factor + tsunami factor
    mag_factor = max(0, (max_mag - 5.0) * 12)  # 5.0→0, 7.0→24, 8.0→36
    count_factor = min(20, count * 1.5)
    tsunami_factor = tsunami_count * 10

    score = min(100, 10 + mag_factor + count_factor + tsunami_factor)

    return {
        "score": round(score, 1),
        "earthquake_count": count,
        "max_magnitude": max_mag,
        "tsunami_warnings": tsunami_count,
        "recent_quakes": quakes[:5],
        "detail": f"{count} séismes M5+ (30j) | Max M{max_mag:.1f} | {tsunami_count} alertes tsunami",
    }


# ---------------------------------------------------------------------------
# Composite Geopolitical Risk Score
# ---------------------------------------------------------------------------

COMPONENT_WEIGHTS = {
    "conflict": 0.35,
    "supply_chain": 0.25,
    "theater": 0.25,
    "infrastructure": 0.15,
}


def _risk_regime(score: float) -> str:
    """Map score to a risk regime label."""
    if score < 20:
        return "CALME"
    elif score < 40:
        return "MODERE"
    elif score < 60:
        return "ELEVE"
    elif score < 80:
        return "CRITIQUE"
    else:
        return "EXTREME"


def _risk_color(score: float) -> str:
    if score < 20:
        return "#70AD47"
    elif score < 40:
        return "#9DC3E6"
    elif score < 60:
        return "#FFD966"
    elif score < 80:
        return "#F4B942"
    return "#C00000"


def _generate_alerts(conflict: dict, supply_chain: dict, theater: dict, infra: dict) -> list:
    """Generate alert messages from component data."""
    alerts = []

    if conflict["score"] >= 60:
        alerts.append({
            "level": "DANGER",
            "type": "danger",
            "text": f"Intensité des conflits élevée ({conflict['score']:.0f}/100) — {conflict['article_count']} articles, tonalité {conflict['avg_tone']:.1f}",
        })
    elif conflict["score"] >= 40:
        alerts.append({
            "level": "ALERTE",
            "type": "warning",
            "text": f"Tensions géopolitiques en hausse — tonalité média {conflict['avg_tone']:.1f}",
        })

    # Chokepoint alerts
    for cp in supply_chain.get("chokepoints", []):
        if cp["risk"] >= 65:
            alerts.append({
                "level": "DANGER",
                "type": "danger",
                "text": f"Risque élevé sur {cp['name']} ({cp['risk']:.0f}/100) — {cp['impact']}",
            })
        elif cp["risk"] >= 50:
            alerts.append({
                "level": "ALERTE",
                "type": "warning",
                "text": f"Surveillance accrue sur {cp['name']} ({cp['risk']:.0f}/100)",
            })

    # Theater alerts
    for t in theater.get("theaters", []):
        if t["score"] >= 60:
            alerts.append({
                "level": "DANGER",
                "type": "danger",
                "text": f"Risque élevé en {t['name']} ({t['score']:.0f}/100) — {t['article_count']} articles",
            })

    # Infrastructure alerts
    if infra.get("max_magnitude", 0) >= 7.0:
        alerts.append({
            "level": "DANGER",
            "type": "danger",
            "text": f"Séisme majeur M{infra['max_magnitude']:.1f} détecté — risque infrastructurel",
        })
    if infra.get("tsunami_warnings", 0) > 0:
        alerts.append({
            "level": "ALERTE",
            "type": "warning",
            "text": f"{infra['tsunami_warnings']} alerte(s) tsunami active(s)",
        })

    # Sort by severity
    severity_order = {"DANGER": 0, "ALERTE": 1, "INFO": 2}
    alerts.sort(key=lambda a: severity_order.get(a["level"], 9))

    return alerts[:8]  # Max 8 alerts


def _build_geopolitical_result() -> dict:
    """Build the full geopolitical risk dashboard (may take ~50s due to GDELT throttle)."""
    print("[GEO] Computing geopolitical risk data...")
    t0 = _time.time()

    # Compute all components (GDELT calls are rate-limited internally)
    conflict = _compute_conflict_intensity()
    print(f"[GEO]   Conflict done: score={conflict['score']}, articles={conflict['article_count']}")

    supply_chain = _compute_chokepoint_risk()
    print(f"[GEO]   Supply chain done: score={supply_chain['score']}")

    theater = _compute_theater_risk()
    print(f"[GEO]   Theaters done: score={theater['score']}")

    infra = _compute_infrastructure_risk()
    print(f"[GEO]   Infrastructure done: score={infra['score']}")

    # Composite score
    composite = (
        conflict["score"] * COMPONENT_WEIGHTS["conflict"]
        + supply_chain["score"] * COMPONENT_WEIGHTS["supply_chain"]
        + theater["score"] * COMPONENT_WEIGHTS["theater"]
        + infra["score"] * COMPONENT_WEIGHTS["infrastructure"]
    )
    composite = round(max(0, min(100, composite)), 1)

    regime = _risk_regime(composite)
    alerts = _generate_alerts(conflict, supply_chain, theater, infra)

    # Sub-scores for display
    sub_scores = [
        {
            "name": "Intensité Conflits",
            "score": conflict["score"],
            "weight": f"{int(COMPONENT_WEIGHTS['conflict'] * 100)}%",
            "color": _risk_color(conflict["score"]),
            "kpis": [
                {"label": "Articles (7j)", "value": str(conflict["article_count"]), "alert": conflict["article_count"] > 200},
                {"label": "Tonalité moy.", "value": f"{conflict['avg_tone']:.1f}", "alert": conflict["avg_tone"] < -3},
            ],
        },
        {
            "name": "Supply Chain",
            "score": supply_chain["score"],
            "weight": f"{int(COMPONENT_WEIGHTS['supply_chain'] * 100)}%",
            "color": _risk_color(supply_chain["score"]),
            "kpis": [
                {"label": "Chokepoints à risque", "value": str(sum(1 for c in supply_chain["chokepoints"] if c["risk"] >= 50)), "alert": False},
                {"label": "Risque max", "value": f"{supply_chain['chokepoints'][0]['name']}: {supply_chain['chokepoints'][0]['risk']:.0f}" if supply_chain["chokepoints"] else "N/A", "alert": supply_chain["chokepoints"][0]["risk"] >= 60 if supply_chain["chokepoints"] else False},
            ],
        },
        {
            "name": "Théâtres d'Opérations",
            "score": theater["score"],
            "weight": f"{int(COMPONENT_WEIGHTS['theater'] * 100)}%",
            "color": _risk_color(theater["score"]),
            "kpis": [
                {"label": "Zones actives", "value": str(sum(1 for t in theater["theaters"] if t["score"] >= 40)), "alert": False},
                {"label": "Zone la + tendue", "value": f"{max(theater['theaters'], key=lambda x: x['score'])['name']}: {max(theater['theaters'], key=lambda x: x['score'])['score']:.0f}" if theater["theaters"] else "N/A", "alert": False},
            ],
        },
        {
            "name": "Risque Infrastructurel",
            "score": infra["score"],
            "weight": f"{int(COMPONENT_WEIGHTS['infrastructure'] * 100)}%",
            "color": _risk_color(infra["score"]),
            "kpis": [
                {"label": "Séismes M5+ (30j)", "value": str(infra["earthquake_count"]), "alert": infra["earthquake_count"] > 10},
                {"label": "Magnitude max", "value": f"M{infra['max_magnitude']:.1f}" if infra["max_magnitude"] > 0 else "N/A", "alert": infra.get("max_magnitude", 0) >= 7.0},
            ],
        },
    ]

    # Check if any theater has 0 articles (likely rate-limit miss)
    has_missing_data = any(t["article_count"] == 0 for t in theater["theaters"])

    result = {
        "composite_score": composite,
        "regime": regime,
        "regime_color": _risk_color(composite),
        "sub_scores": sub_scores,
        "alerts": alerts,
        "chokepoints": supply_chain["chokepoints"],
        "theaters": theater["theaters"],
        "earthquakes": infra.get("recent_quakes", []),
        "updated_at": datetime.utcnow().isoformat(),
        "sources": ["GDELT Project (GKG API)", "USGS Earthquake Hazards"],
        "_complete": not has_missing_data,
    }

    elapsed = _time.time() - t0
    if has_missing_data:
        missing = [t["name"] for t in theater["theaters"] if t["article_count"] == 0]
        print(f"[GEO] Geopolitical data PARTIAL in {elapsed:.1f}s — missing data for: {', '.join(missing)}")
    else:
        print(f"[GEO] Geopolitical data COMPLETE in {elapsed:.1f}s")

    return result


def fetch_geopolitical_risk() -> dict:
    """
    Main entry point. Returns the full geopolitical risk dashboard.
    If background pre-fetch is running, waits for it (with timeout).
    If previous result had missing theaters, retries those specifically.
    """
    cache_key = "geopolitical_risk_full"

    # Check if we have a cached result
    cached = None
    if _is_cached(cache_key):
        cached = _get_cache(cache_key)
        # If the result is complete, return it
        if cached.get("_complete", True):
            return cached
        # If incomplete, check if cached less than 2 min ago (don't retry too fast)
        age = datetime.now().timestamp() - _cache_ts.get(cache_key, 0)
        if age < 120:  # Less than 2 min old — return partial result for now
            return cached
        # Older than 2 min and incomplete — try to fill in the gaps
        print("[GEO] Cached result is incomplete, retrying missing theaters...")

    # If background fetch is in progress, wait up to 90s for it
    if _bg_fetch_started and not _bg_fetch_done.is_set():
        print("[GEO] Waiting for background pre-fetch to complete...")
        _bg_fetch_done.wait(timeout=90)
        if _is_cached(cache_key):
            return _get_cache(cache_key)

    # If we have a partial result, try patching just the missing theaters
    if cached and not cached.get("_complete", True):
        result = _patch_missing_theaters(cached)
        _set_cache(cache_key, result)
        return result

    # Full compute from scratch
    result = _build_geopolitical_result()
    _set_cache(cache_key, result)
    return result


def _patch_missing_theaters(existing: dict) -> dict:
    """Retry only the theaters that had 0 articles in the previous result."""
    import copy
    result = copy.deepcopy(existing)
    theaters = result.get("theaters", [])
    patched = False

    for i, t in enumerate(theaters):
        if t["article_count"] == 0:
            name = t["name"]
            theater_cfg = THEATERS.get(name)
            if not theater_cfg:
                continue
            print(f"[GEO] Retrying theater: {name}")
            query = " OR ".join(theater_cfg["keywords"][:4])
            result_data = _get_gdelt_tone_volume(query, timespan="7d", fetch_articles=False)
            if result_data["count"] > 0:
                # Recompute score
                base = 30
                if result_data["count"] > 500:
                    base += min(30, result_data["count"] / 500)
                elif result_data["count"] > 100:
                    base += min(20, result_data["count"] / 50)
                elif result_data["count"] > 0:
                    base += min(10, result_data["count"] / 10)
                if result_data["avg_tone"] < -2:
                    base += min(20, abs(result_data["avg_tone"]) * 3)
                score = min(100, base)

                theaters[i] = {
                    "name": name,
                    "score": round(score, 1),
                    "weight": theater_cfg["weight"],
                    "article_count": result_data["count"],
                    "tone": result_data["avg_tone"],
                    "top_articles": [],
                }
                patched = True
                print(f"[GEO]   Patched {name}: score={score:.1f}, articles={result_data['count']}")

    if patched:
        # Recalculate theater composite and overall composite
        theater_composite = sum(t["score"] * t["weight"] for t in theaters)
        result["theaters"] = theaters

        # Rebuild sub_scores theater entry
        for ss in result.get("sub_scores", []):
            if ss["name"] == "Théâtres d'Opérations":
                ss["score"] = theater_composite
                ss["color"] = _risk_color(theater_composite)
                ss["kpis"] = [
                    {"label": "Zones actives", "value": str(sum(1 for t in theaters if t["score"] >= 40)), "alert": False},
                    {"label": "Zone la + tendue", "value": f"{max(theaters, key=lambda x: x['score'])['name']}: {max(theaters, key=lambda x: x['score'])['score']:.0f}" if theaters else "N/A", "alert": False},
                ]

        # Recalculate composite
        scores = {ss["name"]: ss["score"] for ss in result.get("sub_scores", [])}
        composite = (
            scores.get("Intensité Conflits", 50) * COMPONENT_WEIGHTS["conflict"]
            + scores.get("Supply Chain", 40) * COMPONENT_WEIGHTS["supply_chain"]
            + theater_composite * COMPONENT_WEIGHTS["theater"]
            + scores.get("Risque Infrastructurel", 15) * COMPONENT_WEIGHTS["infrastructure"]
        )
        composite = round(max(0, min(100, composite)), 1)
        result["composite_score"] = composite
        result["regime"] = _risk_regime(composite)
        result["regime_color"] = _risk_color(composite)

    # Check completeness
    result["_complete"] = not any(t["article_count"] == 0 for t in theaters)
    result["updated_at"] = datetime.utcnow().isoformat()

    return result


def start_background_fetch():
    """Start background pre-fetch of geopolitical data.
    Call this at server startup so data is ready when users first request it.
    """
    global _bg_fetch_started

    if _bg_fetch_started:
        return

    _bg_fetch_started = True

    def _bg_worker():
        try:
            print("[GEO] Background pre-fetch starting...")
            result = _build_geopolitical_result()
            _set_cache("geopolitical_risk_full", result)

            # If some theaters are missing, retry them after a cooldown
            if not result.get("_complete", True):
                missing = [t["name"] for t in result.get("theaters", []) if t["article_count"] == 0]
                print(f"[GEO] Background fetch incomplete, missing: {', '.join(missing)}")
                print("[GEO] Waiting 30s before retry...")
                _time.sleep(30)  # Long cooldown before retrying
                print("[GEO] Retrying missing theaters...")
                patched = _patch_missing_theaters(result)
                _set_cache("geopolitical_risk_full", patched)
                if patched.get("_complete", False):
                    print("[GEO] Background fetch now COMPLETE after retry!")
                else:
                    still_missing = [t["name"] for t in patched.get("theaters", []) if t["article_count"] == 0]
                    print(f"[GEO] Still missing after retry: {', '.join(still_missing)}")
            else:
                print("[GEO] Background pre-fetch COMPLETE!")
        except Exception:
            print("[GEO] Background pre-fetch failed:")
            traceback.print_exc()
        finally:
            _bg_fetch_done.set()

    t = threading.Thread(target=_bg_worker, daemon=True)
    t.start()
